% plot some important results
clear all;
clc;
addpath('PreparedData\',"Results\",'Collected_Raw_Data\');
rng('default')
%% Plot some raw data scatters
figure(1)
% Example Condition 1 (minimum speed and minimum load)
load('Raw_100_0.mat');
subplot(2,4,1)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(a)'})
% Example Condition 4 (minimum speed and high load)
load('Raw_100_900.mat');
subplot(2,4,2)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(b)'})
legend('off')
% Example Condition 8 (average speed and load)
load('Raw_300_500.mat');
subplot(2,4,3)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(c)'})
legend('off')
% Example Condition 13 (maximum speed and load)
load('Raw_500_500.mat');
subplot(2,4,4)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(d)'})
legend('off')
%% Plot some prepared data scatters
figure(1)
% Example Condition 1 (minimum speed and minimum load)
load('100_0.mat');
subplot(2,4,5)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(e)'})
legend('off')
% Example Condition 4 (minimum speed and high load)
load('100_900.mat');
subplot(2,4,6)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(f)'})
legend('off')
% Example Condition 8 (average speed and load)
load('300_500.mat');
subplot(2,4,7)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(g)'})
legend('off')
% Example Condition 13 (maximum speed and load)
load('500_500.mat');
subplot(2,4,8)
X=tsne(X);
figure(1)
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne1,tsne2,Y,[],'*');
xlabel({'tsne1','(h)'})
legend('off')
%% Plot (results)

clear 
clc
% Dl model (i.e. round '0')
load('Results_LSTM_Transfer_0.mat');
% treat NaN values as missong
for i=1:size(MeanMetrics,1)
Values=  MeanMetrics(i,:);
idx       = isnan(Values);
idx       = find(idx==1);
Values(idx) = missing;% treat inf values as missing values
Values= fillmissing(Values,'previous');% fill missing values with previous ones
MeanMetrics(i,:)=Values;
 %
end
%
figure(2)
subplot(2,1,1)
bar(MeanMetrics);
xlabel({'Working conditions','(a)'})
ylabel('Performances')
legend('Accuracy','Recall','F1-score','Precision');
% CSIDTL model (i.e. diferent rounds)
clear
clc
load('Results_Best.mat');
subplot(2,1,2)
bar(BestMetrics);
xlabel({'Working conditions','(b)'})
ylabel('Performances')
%legend('Accuracy','Recall','F1-score','Precision');

