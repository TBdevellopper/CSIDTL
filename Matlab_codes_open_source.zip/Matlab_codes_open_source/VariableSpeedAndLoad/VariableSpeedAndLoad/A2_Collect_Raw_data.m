% This file is dedecated to only collect raw data in a single file (X, Y) without any processing
% The goal is to use these files for vesualization compared to prepared
% data and observe the differences 
%
%
%
%
clear all;
clc;
addpath('Data_processing\','RawData\');
% Prepare working conditions of entire datasets (Speed & voltage load)
load('FileNames.mat');
Speed =[100,200,300,400,500]; 
Voltageload{1,1}=[0 500 700 900];
Voltageload{2,1}=[500 700 900];
Voltageload{3,1}=[500 700 900];
Voltageload{4,1}=[500 700];
Voltageload{5,1}=500;
% Initialize feature extruction parameters
subsamplingrate=0.001;
% Perform extruction and processing process for all conditions 
for i=1:length(Speed)
    for j=1:length(Voltageload{i,1})
desiredSpeed=Speed(i);
desiredVoltage=Voltageload{i,1}(j);
[X,Y]=Collect_Raw_data_Politecnico_di_Torino...
     (FileNames,desiredSpeed,desiredVoltage,subsamplingrate);
     filename=['Collected_Raw_Data\\' 'Raw_' num2str(desiredSpeed) '_' num2str(desiredVoltage) '.mat'] ;
     save(filename,'X','Y');
    end
end

