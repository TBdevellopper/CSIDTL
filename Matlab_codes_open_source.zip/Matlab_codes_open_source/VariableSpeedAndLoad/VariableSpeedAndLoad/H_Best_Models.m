% This script tends to collect best obtained results from the collaborative sellection deep transfer learning model 
% It records best results and bet rounds where such results are obtained.
clear
clc
addpath('Results\')
%
rounds=5;
BestMetrics=[];
for j=1:13
    for i=0:rounds
filenames=sprintf('Results_LSTM_Transfer_%i.mat',i);
load(filenames);
acc(i+1)=MeanMetrics(j,1);
    end
  
[~,round]=max(acc);
round=round-1;
filenames=sprintf('Results_LSTM_Transfer_%i.mat',round);
load(filenames)
  % Treat NaN values as missing values
BestValues=  MeanMetrics(j,:);
idx       = isnan(BestValues);
idx       = find(idx==1);
BestValues(idx) = missing;% treat inf values as missing values
BestValues= fillmissing(BestValues,'previous');% fill missing values with previous ones
  %
BestMetrics=[BestMetrics; BestValues];
BestModel(j,1)=round;
end
clearvars -except BestMetrics BestModel
save('Results\\Results_Best.mat')