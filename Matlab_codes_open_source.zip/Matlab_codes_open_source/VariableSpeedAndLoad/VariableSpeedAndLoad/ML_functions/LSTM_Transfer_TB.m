function [network]= LSTM_Transfer_TB(xtr,ytr,xts,yts,options,Neurons,InputWeights,RecurrentWeights,Bias)
%% Build classifiction model with net network 
%% Trensfer means "Transfer learning"
%% Here transfer learning works by finetuning of parameters of already trained neural network
%% Observations should be organized horizantally (Features,observations)
featureDimension=size(xtr,1);
numResponses= numel(unique(ytr));
%% Layers identification
numHiddenUnits = Neurons;
layers = [ ...
    sequenceInputLayer(featureDimension)
    lstmLayer(numHiddenUnits,'OutputMode','sequence',...
                                 'InputWeights',InputWeights,...
                                 'Bias',Bias,...
                                 'RecurrentWeights',RecurrentWeights)
    fullyConnectedLayer(numResponses)
    softmaxLayer
    classificationLayer('Name','output')];
%% Training
[net,info] = trainNetwork(xtr,ytr,layers,options);
% Evaluate Training
ytr_hat =classify(net,xtr);
Metrics_tr= Metrics_class(ytr,ytr_hat);
%% Testing
yts_hat =classify(net,xts);
% Evaluate Testing
Metrics_ts= Metrics_class(yts,yts_hat);
%% Save results
network.net=net;                 % trained net
network.info=info;               % information about trained net
network.Metrics_tr=Metrics_tr;
network.Metrics_ts=Metrics_ts;
network.yts_hat=yts_hat;
end