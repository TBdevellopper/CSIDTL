% The script 'E_round_3.mat' tends to excute the training process at round
% "three". Meaning that the experement will be done a deep learning model
% with additional transfer learning sources
% the deep learning model in this case is the LSTM Netwok.
% Hyper parameters in this case are adjusted manually using error-trial
% basis
%
% Results of these expeprments will be save in 'Results\\Results_LSTM_Transfer_3.mat'
%
% Results contan: MeanMetrics, network, and TimeElapsed
% MeanMetrics means the mean of cross validation results per working
% condtion
%
% network contain results saved by "LSTM_TB_Transfer.m" (Please check "LSTM_TB_Transfer.m" files for
% further details);
%
% TimeElapsed: Time token during entire experment of this file only.
clear
clc
addpath('PreparedData\','ML_functions\','Results\');
rng('default')
% 
load("Results_LSTM_Transfer_0.mat");
network1=network;
load("Results_LSTM_Transfer_1.mat");
network2=network;
load("Results_LSTM_Transfer_2.mat");
network3=network;
network=[network1;network1;network3];
[InputWeights,RecurrentWeights,Bias]=aggregate(network);
clearvars -except Bias InputWeights RecurrentWeights
%%
Speed =[100,200,300,400,500]; 
Voltageload{1,1}=[0 500 700 900];
Voltageload{2,1}=[500 700 900];
Voltageload{3,1}=[500 700 900];
Voltageload{4,1}=[500 700];
Voltageload{5,1}=500;
%
maxEpochs=600;
miniBatchSize =200;
Neurons=40;
disp ('training-progress')
tic;
c=0;% index of working conditions
%
for j=1:length(Speed)
for k=1:length(Voltageload{j,1})
c=c+1
desiredSpeed=Speed(j);
desiredVoltage=Voltageload{j,1}(k);
filename=['PreparedData\\' num2str(desiredSpeed) '_' num2str(desiredVoltage) '.mat'] ;
load(filename)
%%
% Training & testing
folds=3;
indices = crossvalind('Kfold',Y,folds,'Class',{'0','1','2','3','4','5','6'});
for i=1:folds
test = (indices == i); 
train = ~test;
xtr=X(train,:)';
ytr=Y(train)';
xts=X(test,:)';
yts=Y(test)';
%
options = trainingOptions('rmsprop', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.01, ...
    'ValidationData', {xts,yts},...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'ExecutionEnvironment','cpu',...
    'L2Regularization',0.0001,...
    'Verbose',0);
%'Plots','training-progress',...
%
[network{c,i}]= LSTM_Transfer_TB(xtr,ytr,xts,yts,options,Neurons,...
                                 InputWeights,...
                                 RecurrentWeights,...
                                 Bias);
end
%
METRICS=[];
for i = 1:size(network,2)
    METRICS=[METRICS; network{c, i}.Metrics_ts.Accuracy,...
                      network{c, i}.Metrics_ts.Recall, ...
                      network{c, i}.Metrics_ts.F1,...
                      network{c, i}.Metrics_ts.Precision];
end
MeanMetrics(c,1:4)=mean(METRICS,1);
end
end
GlobalMean = mean(MeanMetrics,1);
%%
TimeElapsed=toc;
clearvars -except MeanMetrics TimeElapsed network GlobalMean
save('Results\\Results_LSTM_Transfer_3.mat')


