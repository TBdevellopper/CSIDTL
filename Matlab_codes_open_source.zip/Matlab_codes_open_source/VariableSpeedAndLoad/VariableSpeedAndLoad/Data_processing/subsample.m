function [X_new]=subsample(X,subsampling_rate)
% subsamplingrate: [0;1] rete of sampling of the signal.
% include samples as (signals x channels)
Q=size(X,1);
[subsampling_idx] = divideint(Q,subsampling_rate,0,1-subsampling_rate);
X_new=X(subsampling_idx,:);
end