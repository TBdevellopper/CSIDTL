function [X,Y]=Size_of_data(FileNames,desiredSpeed,desiredVoltage)
% determine size of dataset
X=[];
Y=[];
c=0;
for i=1:size(FileNames,1)
    label=str2num(FileNames(i,2));
    % ~~~ To sellect specific health conditions ('speed and voltage load')
    Speed=str2num(FileNames(i,5:7));
    LoadVoltage= str2num(FileNames(i,9:11));
    member=ismember(LoadVoltage,desiredVoltage-(5*desiredVoltage/100):desiredVoltage+(5*desiredVoltage/100));
    if Speed==desiredSpeed &  member==1
    % ~~~~
    c=c+1;
    data=struct2array(load(FileNames(i,:)));
    X=[X; data];
    Y=[Y; zeros(size(data,1),1)+label];% identify labels
    end

end
clearvars -except X Y
end