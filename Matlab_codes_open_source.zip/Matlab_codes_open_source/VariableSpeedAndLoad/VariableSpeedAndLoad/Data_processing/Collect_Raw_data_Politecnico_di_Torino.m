function [X,Y]=Collect_Raw_data_Politecnico_di_Torino(FileNames,desiredSpeed,desiredVoltage,subsamplingrate)
X=[];
Y=[];
c=0;
for i=1:size(FileNames,1)
    label=str2num(FileNames(i,2));
    % ~~~ To sellect specific health conditions ('speed and voltage load')
    Speed=str2num(FileNames(i,5:7));
    LoadVoltage= str2num(FileNames(i,9:11));
    member=ismember(LoadVoltage,desiredVoltage-(5*desiredVoltage/100):desiredVoltage+(5*desiredVoltage/100));
    if Speed==desiredSpeed &  member==1
    % ~~~~
    c=c+1;
    data=struct2array(load(FileNames(i,:)));
    Features=subsample(data,subsamplingrate);% Extract and process features
    X=[X; Features];
    Y=[Y; zeros(size(Features,1),1)+label];% identify labels
    end

end
clearvars -except X Y
Y=categorical(Y);
%% Class balance smote technique
[X,Y]=SMOTE(X,Y);
%
end