function [Xn]= gettimewindows(X,Windowlength,Overlapping)
% divide data into time windows
% obsevation should be orgenized as (observation,features);
% X: inputs
% Windowlength= number of samples in a time window
% Overlapping = number of overlapped samples
% number of data samples
nData=size(X,1);
% dividion process 

c=0;
n=1;
while n < nData
    c=c+1;
    Leap=n+Windowlength-1;
    if Leap>nData
    break
    end
    Xt= X(n:Leap,:); 
    Xn(c,1:numel(Xt))=Xt(:)';
    n=n+Windowlength-Overlapping;
end

end

