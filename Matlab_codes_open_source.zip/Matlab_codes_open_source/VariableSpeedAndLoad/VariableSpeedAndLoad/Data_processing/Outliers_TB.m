function[X]=Outliers_TB(X)
% Removing outliers
[~,TF] = rmoutliers(X);
X(TF==1,:)=[];
end