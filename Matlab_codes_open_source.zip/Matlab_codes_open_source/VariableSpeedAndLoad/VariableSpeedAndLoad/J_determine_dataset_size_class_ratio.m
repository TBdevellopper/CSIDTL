% J_determine_dataset_size_class_ratio.m
% this file is addedd to answer some revisions comments of the paper and
% are not necessarly to be done separetly from previous codes.
clear all;
clc;
addpath('Data_processing\','RawData\');
% Prepare working conditions of entire datasets (Speed & voltage load)
load('FileNames.mat');
Speed =[100,200,300,400,500]; 
Voltageload{1,1}=[0 500 700 900];
Voltageload{2,1}=[500 700 900];
Voltageload{3,1}=[500 700 900];
Voltageload{4,1}=[500 700];
Voltageload{5,1}=500;
% Initialize feature extruction parameters
Windowlength=100;
Overlaplength=0;
subsamplingrate=0.1;
% Perform extruction and processing process for all conditions
Data=[];
Labels=[];
for i=1:length(Speed)
    for j=1:length(Voltageload{i,1})
desiredSpeed=Speed(i);
desiredVoltage=Voltageload{i,1}(j);
[Data_temp,Labels_temp]=Size_of_data(FileNames,desiredSpeed,desiredVoltage);
Data=[Data;Data_temp];
Labels=[Labels;Labels_temp];
    end
end
clearvars -except Data Labels
%% detrmine class ratio
I=unique(Labels);
for i=1:length(I)
Idx=find(Labels==I(i));
ratio(i)=length(Idx)/length(Labels);
end
%clearvars -except SizeData ratio
