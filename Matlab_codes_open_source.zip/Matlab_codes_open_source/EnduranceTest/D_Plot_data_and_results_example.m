% This file is dedicted to plot some important results
% Not all results are ilustrated in this case.
% Readers can explore a wider range of results from the stored results in
% 'Results' folder.
clear all;
clc;
addpath('Prepared_data\','Results\','Raw_data_collected\');
%% plot raw data
figure(1)
subplot(1,2,1)
load('Raw_E4A_Collected.mat');
X=tsne(X);
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne2,tsne1,Y,[],'*');
xlabel({'tsne1','(a)'})
% Plot some data scatters
subplot(1,2,2)
load('E4A.mat');
X=tsne(X);
idx1=2;
idx2=1;
tsne1=X(:,idx1);
tsne2=X(:,idx2);
gscatter(tsne2,tsne1,Y,[],'*');
xlabel({'tsne1','(b)'})
%% plot performances first and last rounds 
figure (2)
clear
clc
%
load ('Results_LSTM_Transfer_0.mat');
MeanTotal=[MeanMetrics];
load ('Results_LSTM_Transfer_1.mat');
MeanTotal=[MeanTotal; MeanMetrics];
clearvars -except MeanTotal
bar(MeanTotal)
xlabel('Round')
xticklabels({'0','1'})
ylabel('Performances')
legend('Accuracy','Recall','F1-score','Precision')
