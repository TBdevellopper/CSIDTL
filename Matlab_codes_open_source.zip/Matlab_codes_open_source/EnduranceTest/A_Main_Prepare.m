% This file is dedicated to prepared the endurance test
% make sure that data of the endurance set is in folder 'Raw_data\'
% 
clear all
clc
addpath('Data_processing\','Raw_data\')
rng('default')
%% Load life cycle measurements 
load FileNamesEndurance.mat;
% identify different ends of endurence tests stages
Begenning1=7;
End1=99;
Begenning2=101;
End2=175;
Begenning3=183;
End3=266;
% initialize different variables for preparation loop
c1=0;% just used to count number of files
c2=0;% just used to count number of files
c3=0;% just used to count number of files
X1=[]; % Variables to stor inputs of each different health stage of the bearing E4A
X2=[]; % Variables to stor inputs of each different health stage of the bearing E4A
X3=[]; % Variables to stor inputs of each different health stage of the bearing E4A
% preparation features
Windowlength=200;  
Overlaplength=20;
subsamplingrate=0.02;
S=0; % Dataset size (original size)
for i=1:size(FileNamesEndurance,1)
aquisition=str2double(FileNamesEndurance(i,end-6:end-4));
if aquisition>= Begenning1 & aquisition<=End1
c1=c1+1
X=struct2array(load(FileNamesEndurance(i,:)));
S=size(X,1)+S;
X1=[X1; DiagMachina(X,subsamplingrate,Windowlength,Overlaplength);];
elseif aquisition>= Begenning2 & aquisition<=End2
c2=c2+1
X=struct2array(load(FileNamesEndurance(i,:)));
S=size(X,1)+S;
X2=[X2; DiagMachina(X,subsamplingrate,Windowlength,Overlaplength)];
elseif aquisition>= Begenning3 & aquisition<=End3
c3=c3+1
X=struct2array(load(FileNamesEndurance(i,:)));
S=size(X,1)+S;
X3=[X3; DiagMachina(X,subsamplingrate,Windowlength,Overlaplength);];
end
end
clearvars -except X1 X2 X3 S
% adding layers of outlier removing 
for i=1:20
    i
X1=Outliers_TB(X1);
X2=Outliers_TB(X2);
X3=Outliers_TB(X3);
end
% define labels
Y1=zeros(size(X1,1),1)+1;
Y2=zeros(size(X2,1),1)+2;
Y3=zeros(size(X3,1),1)+3;
%
X=[X1; X2; X3];
Y=[Y1; Y2; Y3];
Y=categorical(Y);
clearvars -except X Y S
% find class ratio
I=unique(Y);
for i=1:length(I)
Idx=find(Y==I(i));
ratio(i)=length(Idx)/numel(Y);
end
%% SMOTE
[X,Y]=SMOTE(X,Y);% synthetic minority ove sampling thechnique fo data imbalance 
save('Prepared_data\\E4A.mat')% save prepared dataset in 'Prepared_data\'
