function [X_new,Y_new]=SMOTE(X,Y)
% SMOTE: Synthetic Minority Over-sampling Technique
% Resfs:
% [1] N. V. Chawla, K. W. Bowyer, L. O. Hall, and W. P. Kegelmeyer, 
% “SMOTE: Synthetic Minority Over-sampling Technique,” 
% Ecol. Appl., vol. 30, no. 2, p. e02043, Jun. 2011, doi: 10.1613/jair.953.
%
%   Usage:
%   [X_new,Y_new]= mySMOTE(X,Y,k)
%
%   X: Inputs (m x n);
%   Y: Outputs/Y (m x 1); categorical
%   k: Number of nearst neigbors
%   X_new: augmented Inputs.
%   Y_New: augmented Tagrets.

%   MATLAB: datasample, randsample
%% 1) Determine number of samples per classes
class  = unique(Y);% unique class labels
for m=1:numel(class)
    NumsamplesPerClass(m)=numel(find(Y==class(m)));
end
%% Number of required samples per each minority class
[max_Samples]=max(NumsamplesPerClass); % number of maximum samples
for m=1:numel(class)
    samplediff(m)=max_Samples-NumsamplesPerClass(m);
end
%% Oversample minority classes
X_new=[];% New inputs for eah classes (including old and new generated samples);
Y_new=[];% New outputs
for m=1:numel(class)
     X_temp=X(Y==class(m),:);% Get all inputs in each class
    Y_temp=Y(Y==class(m),:);% Get all outputs of each class
    % Generate only the required samples N(m) for each class
    X_smote=datasample(X_temp,samplediff(m));
    X_new  =[X_new;X_temp; X_smote];
    Y_smote(1:size(X_smote,1),1) =Y_temp(1);
    Y_new  =[Y_new;Y_temp; Y_smote];
    clear Y_smote
end
%% Rescaling
for i=1:size(X_new,2)
X_new(:,i)=scaledata(X_new(:,i),0,1); 
end
%%
for i=1:size(X_new,2)
%% handling NaN values
idx=isinf(X_new(:,i));
idx=find(idx==1);
X(idx,i)=missing;
X_new(:,i)=fillmissing(X_new(:,i),'previous');% Filling Inf values
end
end