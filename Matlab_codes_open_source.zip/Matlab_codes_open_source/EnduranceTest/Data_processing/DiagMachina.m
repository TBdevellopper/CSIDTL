function [X]=DiagMachina(X,subsamplingrate,Windowlength,Overlaplength)
% DiagMachina for diagnostic Studies: A Complete Package for  Feature 
% Extraction and Sensor Measurement Processing
% Descirption :
% Tis function allows to extruct and process signals either with
% a single chanel or multichanel recorded measurements.
% 1) The subsampling function dedictated to reducing sampling rate of the
% signal in case of huge frames to reduce complexity of the problem.
% 2) gettimewindows function used to devide data into time windows with
% specifc ovelappingdefined by user.
% ExtrauctFeatures is the main function of extruction nad processing
% it defines features as main health indicators.
% X: input signal orgnized as a matrix with (observation,features); dimenssions
% subsamplingrate: rete of sampling = [0;1];
% Windowlength: Time window length
% Overlaplength: Overlap length
% 
[X]  =  subsample(X,subsamplingrate);
[X]  =  gettimewindows(X,Windowlength,Overlaplength);
[X]  =  ExtrauctFeatures(X);
end