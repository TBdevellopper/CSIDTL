function[X]=Outliers_TB(X)
% Removing outliers with median analysis
[~,TF] = rmoutliers(X,'grubbs');
X(TF==1,:)=[];
% remove outmier with mahalanobis Distance
[~,TF] = lof(X,'Distance','mahalanobis');
X(TF==1,:)=[];
% remove outmier with euclidean Distance
[~,TF] = lof(X,'Distance','euclidean');
X(TF==1,:)=[];
% remove outmier with minkowski Distance
[~,TF] = lof(X,'Distance','minkowski');
X(TF==1,:)=[];
end