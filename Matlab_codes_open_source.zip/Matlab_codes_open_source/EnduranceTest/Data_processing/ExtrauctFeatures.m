function [X]=ExtrauctFeatures(X)
% Fetures extruction function
%% 0) Normelize first
for i=1:size(X,2)
X(:,i)=scaledata(medfilt1(smooth(X(:,i),50)),0,1); 
end
%% 1) Feature extraction
for i=1:size(X,1)
%% 2) Time Domain Features
   v             = X(i,:);
   Mean          = mean(v);
   Std           = std(v);
   Skewness      = skewness(v);
   Kurtosis      = kurtosis(v);
   Peak2Peak     = peak2peak(v);
   RMS           = rms(v);
   CrestFactor   = max(v)/RMS;
   ShapeFactor   = RMS/mean(abs(v));
   ImpulseFactor = max(v)/mean(abs(v));
   MarginFactor  = max(v)/mean(abs(v))^2;
   Energy        = sum(v.^2);

 %% 3) Frequancy domain features
   sk = pkurtosis(v);
   SKMean = mean(sk);
   SKStd = std(sk);
   SKSkewness = skewness(sk);
   SKKurtosis = kurtosis(sk);

  %% 4) More features can be added here 





%% 5) Collect features
Xnew(i,:)=[Mean,Std,Skewness,Kurtosis,Peak2Peak,...
           RMS,CrestFactor,ShapeFactor,ImpulseFactor,...
           MarginFactor,Energy,SKMean,SKStd,...
           SKSkewness,SKKurtosis];% also you can add more features here
end
X=Xnew;
%% 6) Wavelet denoising;
for i=1:size(X,2)
%% 6-1 Sclalling & 6-2 Denoising
if mean(X(:,i))> 0
idx     = isinf(X(:,i));
idx     = find(idx==1);
X(idx,i)= missing;% treat inf values as missing values
X(:,i)  = fillmissing(X(:,i),'previous');% Filling Inf values
% X(:,i)  = wdenoise(scaledata(X(:,i),0,1),1); % Sclalling & Denoising
X(:,i)  = wdenoise(X(:,i),1); % Sclalling & Denoising
end
end
%% 7) Resclaing, smoothing and median filtering
for i=1:size(X,2)
X(:,i)=scaledata(medfilt1(smooth(X(:,i),50)),0,1); 
end
%% 8) Remove  outlier
[X]=Outliers_TB(X);
end