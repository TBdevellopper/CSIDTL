function [X_new]=subsample(X,subsampling_rate)
% Uniform subsampling of a (colomn x channels) signal.
% Subsamplingrate: [0,1] rate of sampling of the signal.
Q=size(X,1);
[subsampling_idx] = divideint(Q,subsampling_rate,0,1-subsampling_rate);
X_new=X(subsampling_idx,:);
end