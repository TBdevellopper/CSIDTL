% The script 'B_round_0.mat' tends to excute the training process at round
% "zero". Meaning that the experiment will be done with a deep learning model
% without any additional transfer learning sources.
% The deep learning model in this case is the LSTM Netwok.
% Hyper parameters in this case are adjusted manually using error-trial
% basis
%
% Results of these expeprments will be save in 'Results\\Results_LSTM_Transfer_0.mat'
%
% Results contan: MeanMetrics, network, and TimeElapsed
% MeanMetrics means the mean of cross validation results per working
% condtion
%
% network contain results saved by "LSTM_TB.m" (Please check "LSTM_TB.m" files for
% further details);
%
% TimeElapsed: Time token during entire experment of this file only. 

clear all;
clc;
addpath('Prepared_data\','ML_functions\');
%
rng('default')
% load data
load('E4A.mat')
% Define training options
maxEpochs=600;
miniBatchSize =200;
Neurons=40;
disp ('training-progress')
tic;
%% Training & testing (cross-validation)
folds=3;
indices = crossvalind('Kfold',Y,folds,'Class',{'1','2','3'});
for i=1:folds
i
test = (indices == i); 
train = ~test;
xtr=X(train,:)';
ytr=Y(train)';
xts=X(test,:)';
yts=Y(test)';
%
options = trainingOptions('rmsprop', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.01, ...
    'ValidationData', {xts,yts},...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'ExecutionEnvironment','cpu',...
    'L2Regularization',0.001,...
    'Verbose',0);
%'Plots','training-progress',...
%
[network{i}]= LSTM_TB(xtr,ytr,xts,yts,options,Neurons);
end
%% Collect metrics
METRICS=[];
for i = 1:size(network,2)
    METRICS=[METRICS; network{i}.Metrics_ts.Accuracy,...
                      network{i}.Metrics_ts.Recall, ...
                      network{i}.Metrics_ts.F1,...
                      network{i}.Metrics_ts.Precision];
end
MeanMetrics=mean(METRICS,1);% averge of each cross-validation expermenet 
%% Save results
TimeElapsed=toc;
clearvars -except MeanMetrics TimeElapsed network
save('Results\\Results_LSTM_Transfer_0.mat')


