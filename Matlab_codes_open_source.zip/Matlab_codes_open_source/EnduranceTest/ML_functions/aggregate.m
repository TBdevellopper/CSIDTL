function [InputWeights,RecurrentWeights,Bias]=aggregate(network)
%% This function used to aggregate parameters of several trained neural networks
%% ("a single layer LSTM in particular")
%% By averagring thier parameters
%% 1) initialize parameters
network=reshape(network,1,numel(network));
InputWeights=zeros(size(network{1}.net.Layers(2, 1).InputWeights));
RecurrentWeights=zeros(size(network{1}.net.Layers(2, 1).RecurrentWeights));
Bias=zeros(size(network{1}.net.Layers(2, 1).Bias));
%% Start collecting and averaging parameters
for i=1:numel(network)
    if network{i}.Metrics_ts.Accuracy>=0.90
    InputWeights=InputWeights+network{i}.net.Layers(2, 1).InputWeights;  
    RecurrentWeights  =RecurrentWeights+network{i}.net.Layers(2, 1).RecurrentWeights;
    Bias=Bias+network{i}.net.Layers(2, 1).Bias;
    end
end
InputWeights=InputWeights/numel(network);
RecurrentWeights=RecurrentWeights/numel(network);
Bias=Bias/numel(network);
end