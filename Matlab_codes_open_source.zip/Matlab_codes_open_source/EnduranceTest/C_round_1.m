% The script 'C_round_1.mat' tends to excute the training process at round
% "one". Meaning that the experement will be done with a deep learning model
% with additional transfer learning sources
% the deep learning model in this case is the LSTM Netwok.
% Hyper parameters in this case are adjusted manually using error-trial
% basis
%
% Results of these expeprments will be save in 'Results\\Results_LSTM_Transfer_1.mat'
%
% Results contan: MeanMetrics, network, and TimeElapsed
% MeanMetrics means the mean of cross validation results per working
% condtion
%
% network contain results saved by "LSTM_TB_Transfer.m" (Please check "LSTM_TB_Transfer.m" files for
% further details);
%
% TimeElapsed: Time token during entire experment of this file only.
clear
clc
rng('default')
%
addpath('Prepared_data\','ML_functions\');
% 
%load('BestParameters.mat')
load('Results\Results_LSTM_Transfer_0.mat');
[InputWeights,RecurrentWeights,Bias]=aggregate(network);
%
load('E4A.mat')
%
maxEpochs=600;
miniBatchSize =200;
Neurons=40;
disp ('training-progress')
tic;
%% Training & testing (cross validation)
folds=3;
indices = crossvalind('Kfold',Y,folds,'Class',{'1','2','3'});
for i=1:folds
i
test = (indices == i); 
train = ~test;
xtr=X(train,:)';
ytr=Y(train)';
xts=X(test,:)';
yts=Y(test)';
%
options = trainingOptions('rmsprop', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.01, ...
    'ValidationData', {xts,yts},...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'ExecutionEnvironment','cpu',...
    'L2Regularization',0.0001,...
    'Verbose',0);
%'Plots','training-progress',...
%
[network{i}]= LSTM_Transfer_TB(xtr,ytr,xts,yts,options,Neurons,InputWeights,RecurrentWeights,Bias);
end
%% Collect metrics
METRICS=[];
for i = 1:size(network,2)
    METRICS=[METRICS; network{i}.Metrics_ts.Accuracy,...
                      network{i}.Metrics_ts.Recall, ...
                      network{i}.Metrics_ts.F1,...
                      network{i}.Metrics_ts.Precision];
end
MeanMetrics=mean(METRICS,1);% averge of each cross-validation expermenet 
%% save results
TimeElapsed=toc;
clearvars -except MeanMetrics TimeElapsed network
save('Results\\Results_LSTM_Transfer_1.mat')


