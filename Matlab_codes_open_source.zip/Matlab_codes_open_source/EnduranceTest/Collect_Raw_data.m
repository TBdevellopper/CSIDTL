% this file is dedicated to just orgenize raw data in a single file (X, Y) without
% any processing steps.
% The goal is to use later of the purpose of data vesulization compared to
% prepared data and see the differences between the two.
clear
clc
%
addpath('Raw_data\');
%
% 
clear all
clc
addpath('Data_processing\','Raw_data\')
rng('default')
%% Load life cycle measurements 

load FileNamesEndurance.mat;
Begenning1=7;
End1=99;
Begenning2=101;
End2=175;
Begenning3=183;
End3=266;
c1=0;
c2=0;
c3=0;
X1=[];
X2=[];
X3=[];
Windowlength=200;   %
Overlaplength=20;
subsamplingrate=0.00003;
for i=1:size(FileNamesEndurance,1)
aquisition=str2double(FileNamesEndurance(i,end-6:end-4));
if aquisition>= Begenning1 & aquisition<=End1
c1=c1+1
X=struct2array(load(FileNamesEndurance(i,:)));
X1=[X1; subsample(X,subsamplingrate)];
elseif aquisition>= Begenning2 & aquisition<=End2
c2=c2+1
X=struct2array(load(FileNamesEndurance(i,:)));
X2=[X2; subsample(X,subsamplingrate)];
elseif aquisition>= Begenning3 & aquisition<=End3
c3=c3+1
X=struct2array(load(FileNamesEndurance(i,:)));
X3=[X3; subsample(X,subsamplingrate)];
end
end
clearvars -except X1 X2 X3
% define labels
Y1=zeros(size(X1,1),1)+1;
Y2=zeros(size(X2,1),1)+2;
Y3=zeros(size(X3,1),1)+3;
%
X=[X1; X2; X3];
Y=[Y1; Y2; Y3];
Y=categorical(Y);
clearvars -except X Y
%% Save data
save('Raw_data_collected\\Raw_E4A_Collected.mat')
